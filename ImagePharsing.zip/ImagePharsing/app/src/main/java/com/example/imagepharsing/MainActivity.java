package com.example.imagepharsing;


import static android.graphics.Color.BLUE;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity {

    private TextView myPokemonName, movieYear;
    private Button myButtonParse;
    private ImageView mySprite;
    private EditText mySearch;
    private RequestQueue myQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myPokemonName = findViewById(R.id.name);
        myButtonParse = findViewById(R.id.button);
        mySprite = findViewById(R.id.imageView);
        mySearch = findViewById(R.id.editTextTextPersonName);
        movieYear = findViewById(R.id.year);

        myQueue = Volley.newRequestQueue(this);


    }

    public void searchButton(View v){
        getRequest();
    }

    private void getRequest(){
        String temp_url = mySearch.getText().toString();
        String url = "https://search.imdbot.workers.dev/?q="+temp_url;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("description");
                            JSONObject details = jsonArray.getJSONObject(0);

                            String title = details.getString("#TITLE");
                            String myPokeSprite = details.getString("#IMG_POSTER");
                            int year = details.getInt("#YEAR");

                            myPokemonName.setText(title);
                            Picasso.with(MainActivity.this).load(myPokeSprite).into(mySprite);
                            movieYear.setText(Integer.toString(year));

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        myQueue.add(request);

    }


}